<?php
/**
 * OpposingAccounts.php
 * Copyright (c) 2017 thegrumpydictator@gmail.com
 *
 * This file is part of Firefly III.
 *
 * Firefly III is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Firefly III is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Firefly III. If not, see <http://www.gnu.org/licenses/>.
 */
declare(strict_types=1);

namespace FireflyIII\Import\Mapper;

use FireflyIII\Models\Account;
use FireflyIII\Models\AccountType;
use FireflyIII\Repositories\Account\AccountRepositoryInterface;

/**
 * Class OpposingAccounts.
 */
class OpposingAccounts implements MapperInterface
{
    /**
     * Get map of opposing accounts.
     *
     * @return array
     */
    public function getMap(): array
    {
        /** @var AccountRepositoryInterface $accountRepository */
        $accountRepository = app(AccountRepositoryInterface::class);
        $set               = $accountRepository->getAccountsByType(
            [
                AccountType::DEFAULT, AccountType::ASSET,
                AccountType::EXPENSE, AccountType::BENEFICIARY,
                AccountType::REVENUE, AccountType::LOAN, AccountType::DEBT,
                AccountType::CREDITCARD, AccountType::MORTGAGE,
            ]
        );
        $list              = [];

        /** @var Account $account */
        foreach ($set as $account) {
            $accountId = (int)$account->id;
            $name      = $account->name;
            $iban      = $account->iban ?? '';
            if ('' !== $iban) {
                $name .= ' (' . $iban . ')';
            }
            // is a liability?
            if (\in_array($account->accountType->type, [AccountType::LOAN, AccountType::DEBT, AccountType::CREDITCARD, AccountType::MORTGAGE], true)) {
                $name = trans('import.import_liability_select') . ': ' . $name;
            }
            $list[$accountId] = $name;
        }
        asort($list);
        $list = [0 => (string)trans('import.map_do_not_map')] + $list;

        return $list;
    }
}
