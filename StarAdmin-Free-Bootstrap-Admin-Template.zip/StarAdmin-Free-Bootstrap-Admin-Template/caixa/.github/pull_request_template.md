<!--
Please read me:

1) DO NOT create a pull request for the MASTER branch.
2) DO NOT create pull requests to add new CURRENCIES.
-->

Fixes issue # (if relevant)

Changes in this pull request:

- 
- 
- 

@JC5
