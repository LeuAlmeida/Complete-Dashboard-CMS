---
name: I have a question or a problem
about: Ask away!

---

I am running Firefly III version x.x.x

**Description**
<!-- (if relevant of course) -->

**Extra info**
<!-- Please add extra info here, such as OS, browser, and the output from the `/debug`-page of your Firefly III installation (click the version at the bottom). --> 



**Bonus points**
<!-- Earn bonus points by:

- Add a screenshot
- Make a drawing
- Donate money (just kidding ;)
- Replicate the problem on the demo site https://demo.firefly-iii.org/
- Remember the human
-->